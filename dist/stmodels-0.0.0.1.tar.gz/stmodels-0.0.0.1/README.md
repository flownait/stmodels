# stmodels

This is a models for some common business analytics processing
[Link](https://github.com/flownait/stmodels)
