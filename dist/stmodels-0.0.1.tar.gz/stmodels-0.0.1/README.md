# stmodels

This is a models for some common business analytics processing
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
